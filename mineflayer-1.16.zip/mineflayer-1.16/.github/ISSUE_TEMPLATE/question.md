---
name: Question
about: Ask a question
title: ''
labels: question
assignees: ''

---

## Versions
 - mineflayer: #.#.#
 - server: vanilla/spigot/paper #.#.#
 - node: #.#.#

## Detailed description of a question
