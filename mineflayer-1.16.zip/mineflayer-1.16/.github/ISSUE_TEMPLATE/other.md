---
name: Other
about: Other stuff
title: ''
labels: ''
assignees: ''

---

## Versions
 - mineflayer: #.#.#
 - server: vanilla/spigot/paper #.#.#
 - node: #.#.#

## Detailed description of a problem
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]
